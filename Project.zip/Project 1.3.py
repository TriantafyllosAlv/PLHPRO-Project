import tkinter
# Εισαγωγή βιβλιοθήκη Tkinter
from tkinter import ttk, messagebox
from tkinter import *
from tkinter.ttk import *
from pandas import DataFrame
import matplotlib.pyplot as plt

# Σύνδεση με τη Βάση
import sqlite3

# Ανοίγουμε τη βάση
with sqlite3.connect("Project.db") as db:
    # Δημιουργούμε ένα αντικείμενο «mycursor» χρησιμοποιώντας τη μέθοδο cursor()
    mycursor = db.cursor()

# Θέτουμε τις μεταβλητές που χρειαζόμαστε σε global επίπεδο
global entry1

# Εισαγωγή γραφικού περιβάλλοντος
window = tkinter.Tk()
# Αλλάζω το όνομα του τίτλου
window.title("Manager")
# Τοποθεσία πάνω στην επιφάνεια εργασίας που θα ανοίγει το πρόγραμμα
window.geometry('1000x800+500+50')
my_text = tkinter.Text(window, font=20, height=4, width=28)


# Δημιουργία Συνάρτησης όπου θα αποθηκεύει το όνομα του χρήστη
def create_user(name):
    try:
        # Τη λειτουργία Insert τη χρησιμοποιούμε όταν θέλουμε να εισάγουμε δεδομένα στη βάση
        sql = "INSERT INTO users (name) VALUES (?)"
        val = (name,)

        # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
        mycursor.execute(sql, val)

        # H λειτουργία commit μονιμοποιήσει τις αλλαγές στη βάση
        db.commit()

        # MessageBox
        messagebox.showinfo("Ολοκληρώθηκε!", "Ο Χρήστης καταχωρήθηκε με επιτυχία!")

    except Exception as e:
        print(e)


# Δημιουργία Συνάρτησης open pdf
def openFile():
    import os
    os.startfile("08.pdf")


# Δημιουργία Συνάρτησης όπου θα δημιουργούμε νεο χρήστη
def new_user():
    nu = Toplevel()
    nu.geometry("300x200")
    nu.title("Είσοδος Χρήστης")
    nu_window = Label(nu, text="Όνομα Χρήστη:")
    nu_entry = tkinter.Entry(nu, width=30)
    nu_button = tkinter.Button(nu, text="Αποθήκευση Χρήστη", command=lambda: create_user(nu_entry.get()))

    nu_window.pack()
    nu_entry.pack()
    nu_button.pack()


# Δημιουργία Συνάρτησης όπου θα αποθηκεύει το όνομα του χρήστη
def select_user(name):
    try:
        # Τη λειτουργία Select from τη χρησιμοποιούμε όταν θέλουμε να επιλέξουμε δεδομένα από βάση
        sql = "SELECT iduser FROM users where name like ?"
        val = (name,)

        # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
        mycursor.execute(sql, val)

        id = mycursor.fetchall()
        global iduser
        iduser = id[0][0]

        # H λειτουργία commit μονιμοποιήσει τις αλλαγές στη βάση
        db.commit()

        # MessageBox
        messagebox.showinfo("Ολοκληρώθηκε!", "Ο Χρήστης επιλέχθηκε με επιτυχία!")
        show_duties()
        show_days()

    except Exception as e:
        print(e)


# Μέθοδος που θα εμφανίζουμε τις υποχρεώσεις
def show_duties():
    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    sql = "SELECT id, title, difficulty, category, time FROM duties WHERE iduser=? ORDER BY difficulty DESC;"
    val = (iduser,)

    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    mycursor.execute(sql, val)

    # Ανακτούμε όλες τις γραμμές με τη μέθοδο fetchall()
    records = mycursor.fetchall()
    if records:
        for i in listBox.get_children():
            listBox.delete(i)

        for i, (id, title, category, time, difficulty) in enumerate(records, start=1):
            listBox.insert("", "end", values=(id, title, category, time, difficulty))
    else:
        # MessageBox όπου εμφανίζει μήνυμα σε περίπτωση κάποιου λάθους
        messagebox.showinfo("Μήνυμα", "Δεν βρέθηκε καμία Υποχρέωση!")
        for i in listBox.get_children():
            listBox.delete(i)


# Συνάρτηση
def add_duties(title, difficulty, category, minutes, iduser):
    time = int(minutes)

    # Καταχώρηση στον πίνακα duties
    # Με τα (?, ?, ?, ?) εισάγονται πολλές εγγραφές
    mycursor.execute('''INSERT INTO duties (title,difficulty,category,time,iduser)
                 VALUES (?, ?, ?, ?, ?)''',
                     (title, difficulty, category, time, iduser))

    # Όταν εκτελείται commit(), αποθηκεύει οποιεσδήποτε αλλαγές που έχουν γίνει
    db.commit()
    messagebox.showinfo('Επιτυχία!', 'Η δραστηριότητα έχει εισαχθεί με επιτυχία!')
    show_duties()


# Μέθοδος που παίρνουμε την πληροφορία από τον πίνακα Δραστηριοτήτων
def GetValue(event):
    try:
        # Διαγράφουμε το περιεχόμενο των entry's(textbox)
        idDuties.delete(0, END)
        titlos.delete(0, END)
        categoria.delete(0, END)
        dyskolia.delete(0, END)
        minutes.delete(0, END)
        row_id = listBox.selection()[0]
        select = listBox.set(row_id)

        # Εισάγουμε την πληροφορία στα entry's(textbox)
        idDuties.insert(0, select['ID'])
        titlos.insert(0, select['Δραστηριότητα'])
        categoria.insert(0, select['Κατηγορία'])
        minutes.insert(0, select['Χρόνος'])
        dyskolia.insert(0, select['Δυσκολία'])
        show_duties()
    except Exception as e:
        print(e)


def up_duties():
    id = idDuties.get()
    title = titlos.get()
    category = categoria.get()
    difficulty = dyskolia.get()
    time = minutes.get()
    try:
        # Η λειτουργία update χρησιμοποιείται για την ενημέρωση
        # μιας ήδη υπάρχουσας εγγραφής στη βάση δεδομένων
        sql = "Update duties set title = ?,category = ?,difficulty = ?,time = ? where id = ?"
        val = (title, category, difficulty, time, id)

        # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
        mycursor.execute(sql, val)

        # H λειτουργία commit μονιμοποιήσει τις αλλαγές στη βάση
        db.commit()

        # MessageBox
        messagebox.showinfo("Ενημέρωση", "Τα στοιχεία της Δραστηριότητας ενημερώθηκαν")

        # Διαγράφουμε το περιεχόμενο των entry's(textbox)
        idDuties.delete(0, END)
        titlos.delete(0, END)
        dyskolia.delete(0, END)
        categoria.delete(0, END)
        minutes.delete(0, END)

        # Μέθοδος που παίρνουμε τις εγγραφές από τη βάση και τις εμφανίζουμε
        show_duties()

    except Exception as e:
        print(e)
        # Η λειτουργία rollback χρησιμοποιείται για την αναίρεση των αλλαγών στη βάση
        db.rollback()
        # αποσύνδεση από το server
        db.close()


# Μέθοδος που διαγράφουμε μία εγγραφή στη βάση
def del_duty():
    try:
        # Με την εντολή delete διαγράφουμε εγγραφές από τη βάση
        sql = "delete from duties where id = ?"
        val = (idDuties.get(),)

        # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
        mycursor.execute(sql, val)

        # H λειτουργία commit μονιμοποιήσει τις αλλαγές στη βάση
        db.commit()

        # MessageBox
        messagebox.showinfo("Διαγραφή", "H δραστηριότητα διαγράφηκε επιτυχώς")

        # Διαγράφουμε το περιεχόμενο των entry's(textbox)
        idDuties.delete(0, END)
        titlos.delete(0, END)
        dyskolia.delete(0, END)
        categoria.delete(0, END)
        minutes.delete(0, END)

        # Μέθοδος που παίρνουμε τις εγγραφές από τη βάση και τις εμφανίζουμε
        show_duties()

    except Exception as e:
        print(e)
        db.rollback()
        # αποσύνδεση από το server
        db.close()


# Μέθοδος που θα εμφανίζουμε τις υποχρεώσεις
def show_days():
    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    sql = "SELECT id, day, spare_time FROM free_time WHERE iduser=?"
    val = (iduser,)

    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    mycursor.execute(sql, val)

    # Ανακτούμε όλες τις γραμμές με τη μέθοδο fetchall()
    records = mycursor.fetchall()
    if records:
        for i in listBox2.get_children():
            listBox2.delete(i)

        for i, (id, day, spare_time) in enumerate(records, start=1):
            listBox2.insert("", "end", values=(id, day, spare_time))
    else:
        # MessageBox όπου εμφανίζει μήνυμα σε περίπτωση κάποιου λάθους
        messagebox.showinfo("Μήνυμα", "Δεν βρέθηκε καμία εγγεγραμμένη ημέρα!")


def add_days(day, minutes):
    spare_time = int(minutes)

    # Καταχώρηση στον πίνακα duties
    # Με τα (?, ?, ?) εισάγονται πολλές εγγραφές
    mycursor.execute('''INSERT INTO free_time (day,spare_time,iduser)
                 VALUES (?, ?, ?)''',
                     (day, spare_time, iduser))

    # Όταν εκτελείται commit(), αποθηκεύει οποιεσδήποτε αλλαγές που έχουν γίνει
    db.commit()
    messagebox.showinfo('Επιτυχία!', 'Η ημέρα έχει εισαχθεί με επιτυχία!')
    show_days()


# Μέθοδος που παίρνουμε την πληροφορία από τον πίνακα Ελεύθερου χρόνου
def GetValue2(event):
    try:
        # Διαγράφουμε το περιεχόμενο των entry's(textbox)
        day_id.delete(0, END)
        hmera.delete(0, END)
        minutes2.delete(0, END)
        row_id = listBox2.selection()[0]
        select = listBox2.set(row_id)

        # Εισάγουμε την πληροφορία στα entry's(textbox)
        day_id.insert(0, select['Α/Α'])
        hmera.insert(0, select['Ημέρα'])
        minutes2.insert(0, select['Χρόνος'])
        show_days()
    except Exception as e:
        print(e)


def up_days():
    id = day_id.get()
    day = hmera.get()
    spare_time = minutes2.get()
    try:
        # Η λειτουργία update χρησιμοποιείται για την ενημέρωση
        # μιας ήδη υπάρχουσας εγγραφής στη βάση δεδομένων
        sql = "Update free_time set day = ?,spare_time = ? where id = ?"
        val = (day, spare_time, id)

        # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
        mycursor.execute(sql, val)

        # H λειτουργία commit μονιμοποιήσει τις αλλαγές στη βάση
        db.commit()

        # MessageBox
        messagebox.showinfo("Ενημέρωση", "Η ημέρα ενημερώθηκε")

        # Διαγράφουμε το περιεχόμενο των entry's(textbox)
        day_id.delete(0, END)
        hmera.delete(0, END)
        minutes.delete(0, END)

        # Μέθοδος που παίρνουμε τις εγγραφές από τη βάση και τις εμφανίζουμε
        show_days()

    except Exception as e:
        print(e)
        # Η λειτουργία rollback χρησιμοποιείται για την αναίρεση των αλλαγών στη βάση
        db.rollback()
        # αποσύνδεση από το server
        db.close()


def sum_time():
    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    sql = "SELECT SUM(time) FROM duties WHERE iduser = ?"
    val = (iduser,)
    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    mycursor.execute(sql, val)
    # Ανακτούμε όλες τις γραμμές με τη μέθοδο fetchall()
    sum = mycursor.fetchall()
    SAX.delete(0, END)
    SAX.insert(0, sum[0])


def free_time():
    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    sql = "SELECT SUM(spare_time) FROM free_time WHERE iduser = ?"
    val = (iduser,)
    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    mycursor.execute(sql, val)
    # Ανακτούμε όλες τις γραμμές με τη μέθοδο fetchall()
    sum = mycursor.fetchall()
    SEL.delete(0, END)
    SEL.insert(0, sum[0])


def avg_time():
    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    sql = "SELECT AVG(time) FROM duties WHERE iduser = ?"
    val = (iduser,)
    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    mycursor.execute(sql, val)
    # Ανακτούμε όλες τις γραμμές με τη μέθοδο fetchall()
    sum = mycursor.fetchall()
    MXD.delete(0, END)
    MXD.insert(0, sum[0])


def Data_Frame():
    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    sql = "SELECT title,time FROM duties WHERE iduser=? ORDER BY difficulty DESC;"
    val = (iduser,)

    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    mycursor.execute(sql, val)

    # Ανακτούμε όλες τις γραμμές με τη μέθοδο fetchall()
    df = DataFrame(mycursor.fetchall())

    df.plot(x=0, y=1, kind="bar")

    # Ορισμός τίτλου του γραφήματος
    plt.title('Χρόνος Εκτέλεσης Δραστηριοτήτων')

    # Ορισμός ετικέτας του άξονα x
    plt.xlabel('Δραστηριότητα')

    # Ορισμός ετικέτας του άξονα y
    plt.ylabel('Χρόνος')

    # Περιστροφή των ετικετών του άξονα x για καλύτερη ανάγνωση
    plt.xticks(rotation=0)

    # Εμφάνιση του γραφήματος
    plt.show()


def Data_Export():
    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    sql = "SELECT id,title,difficulty,category,time FROM duties WHERE iduser=? ORDER BY difficulty DESC;"
    val = (iduser,)

    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    mycursor.execute(sql, val)

    # Ανακτούμε όλες τις γραμμές με τη μέθοδο fetchall()
    df = DataFrame(mycursor.fetchall())
    df.columns = ["id", "Τίτλος", "Δυσκολία", "Κατηγορία", "Χρόνος"]

    try:
        # στη συνέχεια ανοίγει το αρχείο για εγγραφή δεδομένων κειμένου
        # Το όνομα του αρχείου αποθήκευσης θα είναι το όνομα του αρχείου κρατήσεων με επέκταση ‘.txt’.
        tfile = open('export.txt', 'w')
        tfile.write(df.to_string())
        tfile.close()
        # MessageBox
        messagebox.showinfo("Ενημέρωση", "To αρχείο export.txt αποθηκεύτηκε με επιτυχία.")

        # Σε περίπτωση σφάλματος, η συνάρτηση εμφανίζει μήνυμα αποτυχίας εγγραφής.
    except Exception as e:
        print("Σφάλμα κατά την εγγραφή στο αρχείο:", e)


# Με τo pack εμφανίζουμε το παράθυρο
# Create the Menu
menubar = tkinter.Menu(window)

# "donothing" Συνάρτηση που καλείται αν γίνει η επιλογή
# Προσθέτω στο μενού την επιλογή αρχείου
file = tkinter.Menu(menubar, tearoff=0, bg="#DEB887")
menubar.add_cascade(label='App', menu=file)
file.add_command(label='Exit Application', command=window.destroy)

# Προσθέτω στο μενού την επιλογή χρηστών
user = tkinter.Menu(menubar, tearoff=0, bg="#DEB887")
menubar.add_cascade(label="New Users", menu=user)
user.add_command(label='Create New User', command=lambda: new_user())

# Προσθέτω το μενού με τις πληροφορίες εφαρμογής
help_ = Menu(menubar, tearoff=0, bg="#DEB887")
menubar.add_cascade(label='Help', menu=help_)
help_.add_command(label='App Information', command=lambda: openFile())

# Εισαγωγή ετικετών για τις υποχρεώσεις
Label(window, text="Χρήστης:").place(x=10, y=10)
Label(window, text="Δραστηριότητα:").place(x=10, y=40)
Label(window, text="Κατηγορία:").place(x=10, y=70)
Label(window, text="Απαιτούμενος Χρόνος σε Λεπτά:").place(x=10, y=100)
Label(window, text="Βαθμός δυσκολίας:").place(x=10, y=130)

# Δημιουργία των textboxes και επιλογή χρήστη με combobox
# Εκτελώ ερώτημα στη βάση κατευθείαν για την επιλογή χρήστη
user_id = ttk.Combobox(window, width=27)
sql1 = "SELECT name FROM users"
val1 = ()
# εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
mycursor.execute(sql1, val1)
user_id['values'] = (mycursor.fetchall())
user_id.place(x=140, y=10)

ou_button = tkinter.Button(text="Επιλογή", command=lambda: select_user(user_id.get()))
ou_button.place(x=335, y=7)

idDuties = Entry(window, width=3)
idDuties.place(x=110, y=40)

titlos = Entry(window, width=30)
titlos.place(x=140, y=40)
# Δημιουργία combobox για τις κατηγορίες δραστηριοτήτων
choose2 = StringVar()
categoria = ttk.Combobox(window, width=27, textvariable=choose2)
# Δημιουργία λίστας δραστηριοτήτων
categoria['values'] = ("Υποχρέωση", "Ελεύθερου χρόνου")
categoria.place(x=140, y=70)

# Δημιουργία spinbox για εισαγωγή χρόνου
minutes = Spinbox(window, from_=0, to=999, width=5)
minutes.pack()
minutes.place(x=195, y=100)

# Δημιουργία combobox για εισαγωγή δυσκολίας
choose3 = StringVar()
dyskolia = ttk.Combobox(window, width=27, textvariable=choose3)
# Δημιουργία λίστας βαθμού δυσκολίας
dyskolia['values'] = ("1", "2", "3", "4", "5", "6", "7", "8", "9", "10")
dyskolia.place(x=140, y=130)
# Εισαγωγή των buttons
Button(window, text="Προσθήκη",
       command=lambda: add_duties(titlos.get(), dyskolia.get(), categoria.get(), minutes.get(), iduser),
       width=13).place(x=20, y=160)
Button(window, text="Τροποποίηση", command=lambda: up_duties(), width=13).place(x=130, y=160)
Button(window, text="Διαγραφή", command=lambda: del_duty(), width=13).place(x=240, y=160)

# Στήλες του πίνακα δραστηριοτήτων
cols = ('ID', 'Δραστηριότητα', 'Δυσκολία', 'Κατηγορία', 'Χρόνος')

# Η Treeview Επιτρέπει την παρουσίαση πληροφορίας ιεραρχικής δομής
listBox = ttk.Treeview(window, columns=cols, show='headings')
listBox.column('ID', width=30)
listBox.column('Δραστηριότητα', width=140)
listBox.column('Κατηγορία', width=110)
listBox.column('Δυσκολία', width=60)
listBox.column('Χρόνος', width=50)

# Δημιουργούμε τη Scrollbar
sb = ttk.Scrollbar(window, orient="vertical", command=listBox.yview)

# Τοποθετώ την Scrollbar
sb.place(x=400, y=200, height=226)
listBox.configure(yscrollcommand=sb.set)

for col in cols:
    listBox.heading(col, text=col)
    listBox.grid(row=1, column=0, columnspan=2)
    listBox.place(x=10, y=200)

listBox.bind('<Double-Button-1>', GetValue)

# Εισαγωγή ετικετών για τον ελεύθερο χρόνο
Label(window, text="Α/Α").place(x=460, y=10)
Label(window, text="Ημέρα:").place(x=460, y=40)
Label(window, text="Ελεύθερος Χρόνος σε Λεπτά:").place(x=460, y=70)
# Δημιουργία spinbox για εισαγωγή χρόνου
minutes2 = Spinbox(window, from_=0, to=59, width=5)
minutes2.pack()
minutes2.place(x=620, y=70, width=50)

# Textboxes για τον ελεύθερο χρόνο του χρήστη
day_id = Entry(window, width=30)
day_id.place(x=575, y=10)

# Combobox για την επιλογή ημέρας
choose3 = StringVar()
hmera = ttk.Combobox(window, width=27, textvariable=choose3)
hmera['values'] = ("Δευτέρα", "Τρίτη", "Τετάρτη", "Πέμπτη", "Παρασκευή", "Σάββατο", "Κυριακή")
hmera.place(x=575, y=40)

# Εισαγωγή των buttons για τον ελεύθερο χρόνο
Button(window, text="Προσθήκη", command=lambda: add_days(hmera.get(), minutes2.get()), width=13).place(
    x=460, y=100)
Button(window, text="Ενημέρωση", command=lambda: up_days(), width=13).place(x=570, y=100)

# Στήλες του πίνακα ελεύθερου χρόνου
cols2 = ("Α/Α", "Ημέρα", "Χρόνος")

# Η Treeview Επιτρέπει την παρουσίαση πληροφορίας ιεραρχικής δομής
listBox2 = ttk.Treeview(window, columns=cols2, show='headings')
listBox2.column('Α/Α', width=100)
listBox2.column('Ημέρα', width=100)
listBox2.column('Χρόνος', width=100)

for col in cols2:
    listBox2.heading(col, text=col)
    listBox2.grid(row=1, column=0, columnspan=2)
    listBox2.place(x=460, y=140)

listBox2.bind('<Double-Button-1>', GetValue2)

# Εισαγωγή Συνολικού και μέσου χρόνου Δραστηριοτήτων
Label(window, text="Σύνολο Ελεύθερου Χρόνου:").place(x=460, y=377)
SEL = Entry(window, width=6)
SEL.place(x=647, y=377)
Button(window, text="Εμφάνιση", command=lambda: free_time()).place(x=692, y=375)

# Εισαγωγή Συνολικού και μέσου χρόνου Δραστηριοτήτων
Label(window, text="Σύνολο Απαιτούμενου Χρόνου:").place(x=10, y=450)
SAX = Entry(window, width=6)
SAX.place(x=195, y=450)
Button(window, text="Εμφάνιση", command=lambda: sum_time()).place(x=240, y=447)

Label(window, text="Μέσος Χρόνος Δραστηριοτήτων:").place(x=10, y=480)
MXD = Entry(window, width=6)
MXD.place(x=195, y=480)
Button(window, text="Εμφάνιση", command=lambda: avg_time()).place(x=240, y=477)

Button(window, text="Εμφάνιση Ραβδογράμματος", command=lambda: Data_Frame()).place(x=10, y=520)

Button(window, text="Εξαγωγή σε αρχείο", command=lambda: Data_Export()).place(x=10, y=560)

# Θα εμφανίζει ένα status bar
status_bar = Label(window, text="Version 1.3   ", anchor=E)
status_bar.pack(fill=X, side=BOTTOM, ipady=4)

# Εμφάνιση του μενού
window.config(menu=menubar)
window.iconbitmap('freetime.ico')
window.mainloop()