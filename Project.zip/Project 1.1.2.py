import tkinter
# Εισαγωγή βιβλιοθήκη Tkinter
from tkinter import ttk, messagebox
from tkinter import *
from tkinter.ttk import *
from tkinter.filedialog import askopenfile
from tkinter.filedialog import asksaveasfile

# Σύνδεση με τη Βάση
import sqlite3

# Ανοίγουμε τη βάση
with sqlite3.connect("Project.db") as db:
    # Δημιουργούμε ένα αντικείμενο «mycursor» χρησιμοποιώντας τη μέθοδο cursor()
    mycursor = db.cursor()

# Θέτουμε τις μεταβλητές που χρειαζόμαστε σε global επίπεδο
global entry1
global selected
global openfiles

# Εισαγωγή γραφικού περιβάλλοντος
window = tkinter.Tk()
# Αλλάζω το όνομα του τίτλου
window.title("Manager")
# Τοποθεσία πάνω στην επιφάνεια εργασίας που θα ανοίγει το πρόγραμμα
window.geometry('700x700+500+50')
my_text = tkinter.Text(window, font=20, height=4, width=28)


# Μέθοδος που θα εμφανίζουμε τις υποχρεώσεις
def show_duties():
    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    sql = "SELECT id, title, difficulty, category, time FROM duties"
    val = ()

    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    mycursor.execute(sql, val)

    # Ανακτούμε όλες τις γραμμές με τη μέθοδο fetchall()
    records = mycursor.fetchall()
    if records:
        for i in listBox.get_children():
            listBox.delete(i)

        for i, (id, title, category, time, difficulty) in enumerate(records, start=1):
            listBox.insert("", "end", values=(id, title, category, time, difficulty))
    else:
        # MessageBox όπου εμφανίζει μήνυμα σε περίπτωση κάποιου λάθους
        messagebox.showinfo("Μήνυμα", "Δεν βρέθηκε καμία Υποχρέωση!")


# Συνάρτηση
def add_duties(title, difficulty, category, hour, minutes, iduser):
    time = int(hour) * 60 + int(minutes)

    # Καταχώρηση στον πίνακα duties
    # Με τα (?, ?, ?, ?) εισάγονται πολλές εγγραφές
    mycursor.execute('''INSERT INTO duties (title,difficulty,category,time,iduser)
                 VALUES (?, ?, ?, ?, ?)''',
                     (title, difficulty, category, time, iduser))

    # Όταν εκτελείται commit(), αποθηκεύει οποιεσδήποτε αλλαγές που έχουν γίνει
    db.commit()
    messagebox.showinfo('Επιτυχία!', 'Η δραστηριότητα έχει εισαχθεί με επιτυχία!')


# Δημιουργία Συνάρτησης όπου ανοίγει το επιλεγμένο αρχείο
def open_file():
    files = askopenfile(mode='r', filetypes=[("All Files", "*.*"),
                                             ("Database Files", "*.db")])
    if files is not None:
        sqlite3.connect("")
    # Δημιουργούμε ένα αντικείμενο «mycursor» χρησιμοποιώντας τη μέθοδο cursor()
    db.cursor()
    db.commit()


# Δημιουργία Συνάρτησης όπου αποθηκεύει το αρχείο μας
def save_file():
    asksaveasfile(initialfile='Untitled.db', defaultextension=".db",
                  filetypes=[("Database File", "*.db")])


# Δημιουργία Συνάρτησης όπου θα αποθηκεύει το όνομα του χρήστη
def create_user(name):
    try:
        # Τη λειτουργία Insert τη χρησιμοποιούμε όταν θέλουμε να εισάγουμε δεδομένα στη βάση
        sql = "INSERT INTO users (name) VALUES (?)"
        val = (name,)

        # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
        mycursor.execute(sql, val)

        # H λειτουργία commit μονιμοποιήσει τις αλλαγές στη βάση
        db.commit()

        # MessageBox
        messagebox.showinfo("Ολοκληρώθηκε!", "Ο Χρήστης καταχωρήθηκε με επιτυχία!")

    except Exception as e:
        print(e)


# Δημιουργία Συνάρτησης όπου θα δημιουργούμε νεο χρήστη
def new_user():
    nu = Toplevel()
    nu.geometry("300x200")
    nu.title("Είσοδος Χρήστης")
    nu_window = Label(nu, text="Όνομα Χρήστη:")
    nu_entry = tkinter.Entry(nu, width=30)
    nu_button = tkinter.Button(nu, text="Αποθήκευση Χρήστη", command=lambda: create_user(nu_entry.get()))

    nu_window.pack()
    nu_entry.pack()
    nu_button.pack()


# Δημιουργία Συνάρτησης όπου θα αποθηκεύει το όνομα του χρήστη
def select_user(name):
    try:
        # Τη λειτουργία Select from τη χρησιμοποιούμε όταν θέλουμε να επιλέξουμε δεδομένα από βάση
        sql = "SELECT iduser FROM users where name like ?"
        val = (name,)

        # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
        mycursor.execute(sql, val)

        id = mycursor.fetchall()
        global iduser
        iduser = id[0][0]
        print(iduser)

        # H λειτουργία commit μονιμοποιήσει τις αλλαγές στη βάση
        db.commit()

        # MessageBox
        messagebox.showinfo("Ολοκληρώθηκε!", "Ο Χρήστης επιλέχθηκε με επιτυχία!")


    except Exception as e:
        print(e)


def old_user():
    ou = Toplevel()
    ou.geometry("300x200")
    ou.title("Επιλογή Χρήστη")
    ou_window = Label(ou, text="Επιλογή Χρήστη")
    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    sql = "SELECT name FROM users"
    val = ()
    # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
    mycursor.execute(sql, val)
    ou_select = Combobox(ou_window)
    ou_select['values'] = (mycursor.fetchall())
    ou_select.current(0)
    ou_button = tkinter.Button(ou, text="Επιλογή", command=lambda: select_user(ou_select.get()))

    ou_window.pack()
    ou_select.pack()
    ou_button.pack()


# Συνάρτηση οπού θα κάνουμε αποκοπή επιλεγμένων στοιχείων
def cut_text(e):
    global selected
    if e:
        selected = window.clipboard_get()
    else:
        if my_text.selection_get():
            selected = my_text.selection_get()
            my_text.delete("sel.first", "sel.last")
            window.clipboard_clear()
            window.clipboard_append(selected)


def copy_text(e):
    global selected
    if e:
        selected = window.clipboard_get()
    if my_text.selection_get():
        selected = my_text.selection_get()
        window.clipboard_clear()
        window.clipboard_append(selected)


def select_all():
    my_text.tag_add(SEL, "1.0", END)
    my_text.mark_set(INSERT, "1.0")
    my_text.see(INSERT)


def paste_text(e):
    global selected
    if e:
        selected = window.clipboard_get()
    else:
        if selected:
            position = my_text.index(INSERT)
            my_text.insert(position, selected)


# Μέθοδος που παίρνουμε την πληροφορία από τον πίνακα Δραστηριοτήτων
def GetValue(event):
    try:
        # Διαγράφουμε το περιεχόμενο των entry's(textbox)
        duty_id.delete(0, END)
        titlos.delete(0, END)
        categoria.delete(0, END)
        dyskolia.delete(0, END)
        hour.delete(0, END)
        minutes.delete(0, END)
        row_id = listBox.selection()[0]
        select = listBox.set(row_id)

        # Εισάγουμε την πληροφορία στα entry's(textbox)
        duty_id.insert(0, select['ID'])
        titlos.insert(0, select['Δραστηριότητα'])
        categoria.insert(0, select['Κατηγορία'])
        hour.insert(0, select['Χρόνος'])
        minutes.insert(0, select['Χρόνος'])
        dyskolia.insert(0, select['Δυσκολία'])
        show_duties()
    except Exception as e:
        print(e)


def up_duties():
    id = duty_id.get()
    title = titlos.get()
    category = categoria.get()
    difficulty = dyskolia.get()
    time = hour.get() + minutes.get()
    try:
        # Η λειτουργία update χρησιμοποιείται για την ενημέρωση
        # μιας ήδη υπάρχουσας εγγραφής στη βάση δεδομένων
        sql = "Update duties set title = ?,category = ?,difficulty = ?,time = ? where id = ?"
        val = (title, category, difficulty, time, id)

        # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
        mycursor.execute(sql, val)

        # H λειτουργία commit μονιμοποιήσει τις αλλαγές στη βάση
        db.commit()

        # MessageBox
        messagebox.showinfo("Ενημέρωση", "Τα στοιχεία της Δραστηριότητας ενημερώθηκαν")

        # Διαγράφουμε το περιεχόμενο των entry's(textbox)
        titlos.delete(0, END)
        dyskolia.delete(0, END)
        categoria.delete(0, END)
        hour.delete(0, END)
        minutes.delete(0, END)

        # Μέθοδος που παίρνουμε τις εγγραφές από τη βάση και τις εμφανίζουμε
        show_duties()

    except Exception as e:
        print(e)
        # Η λειτουργία rollback χρησιμοποιείται για την αναίρεση των αλλαγών στη βάση
        db.rollback()
        # αποσύνδεση από το server
        db.close()


# Μέθοδος που διαγράφουμε μία εγγραφή στη βάση
def del_duty():
    id = duty_id.get()
    try:
        # Με την εντολή delete διαγράφουμε εγγραφές από τη βάση
        sql = "delete from duties where id = ?"
        val = (id,)

        # εκτελούμε ένα SQL ερώτημα χρησιμοποιώντας τη μέθοδο execute
        mycursor.execute(sql, val)

        # H λειτουργία commit μονιμοποιήσει τις αλλαγές στη βάση
        db.commit()

        # MessageBox
        messagebox.showinfo("Διαγραφή", "H δραστηριότητα διαγράφηκε επιτυχώς")

        # Διαγράφουμε το περιεχόμενο των entry's(textbox)
        titlos.delete(0, END)
        dyskolia.delete(0, END)
        categoria.delete(0, END)
        hour.delete(0, END)
        minutes.delete(0, END)

        # Μέθοδος που παίρνουμε τις εγγραφές από τη βάση και τις εμφανίζουμε
        show_duties()

    except Exception as e:
        print(e)
        db.rollback()
        # αποσύνδεση από το server
        db.close()


# Με τo pack εμφανίζουμε το παράθυρο
# Create the Menu
menubar = tkinter.Menu(window)

# "donothing" Συνάρτηση που καλείται αν γίνει η επιλογή
# Προσθέτω στο μενού την επιλογή αρχείου
file = tkinter.Menu(menubar, tearoff=0)
menubar.add_cascade(label='File', menu=file)
file.add_command(label='Open File', command=lambda: open_file())
file.add_command(label='Save File', command=lambda: save_file())
file.add_separator()
file.add_command(label='Exit Application', command=window.destroy)

# Προσθέτω στο μενού την επιλογή χρηστών
user = tkinter.Menu(menubar, tearoff=0)
menubar.add_cascade(label="Users", menu=user)
user.add_command(label='New Users', command=lambda: new_user())
user.add_command(label='Existing User', command=lambda: old_user())

# Προσθέτω στο μενού την επιλογή επεξεργασίας
edit = tkinter.Menu(menubar, tearoff=0)
menubar.add_cascade(label='Edit', menu=edit)
edit.add_command(label='Copy        Ctrl+C', command=lambda: paste_text(my_text))
edit.add_command(label='Cut         Ctrl+X', command=lambda: cut_text(my_text))
edit.add_command(label='Paste       Ctrl+V', command=lambda: paste_text(my_text))
edit.add_command(label='Select All  Ctrl+A', command=lambda: select_all())

# Προσθέτω το μενού με τις πληροφορίες εφαρμογής
help_ = Menu(menubar, tearoff=0)
menubar.add_cascade(label='Help', menu=help_)
help_.add_command(label='App Information', command="donothing")

# Εισαγωγή ετικετών για τις υποχρεώσεις
Label(window, text="ID:").place(x=10, y=10)
Label(window, text="Δραστηριότητα:").place(x=10, y=40)
Label(window, text="Κατηγορία:").place(x=10, y=70)
Label(window, text="Απαιτούμενος Χρόνος :").place(x=10, y=100)
Label(window, text="Ώρες").place(x=140, y=100)
Label(window, text="Λεπτά").place(x=237, y=100)
Label(window, text="Βαθμός δυσκολίας:").place(x=10, y=130)

# Δημιουργία των textboxes
# title,difficulty,category, time
duty_id = Entry(window, width=30)
duty_id.place(x=140, y=10)
titlos = Entry(window, width=30)
titlos.place(x=140, y=40)
# Δημιουργία combobox για τις κατηγορίες δραστηριοτήτων
choose1 = StringVar()
categoria = ttk.Combobox(window, width=27, textvariable=choose1)
# Δημιουργία λίστας δραστηριοτήτων
categoria['values'] = ("Υποχρέωση", "Ελεύθερου χρόνου")
categoria.place(x=140, y=70)

# Δημιουργία spinbox για εισαγωγή χρόνου
hour = Spinbox(window, from_=0, to=23, width=5)
hour.pack()
hour.place(x=175, y=100)
minutes = Spinbox(window, from_=0, to=59, width=5)
minutes.pack()
minutes.place(x=277, y=100)

# Δημιουργία combobox για εισαγωγή δυσκολίας
choose2 = StringVar()
dyskolia = ttk.Combobox(window, width=27, textvariable=choose2)
# Δημιουργία λίστας βαθμού δυσκολίας
dyskolia['values'] = ("1", "2", "3", "4", "5", "6", "7", "8", "9", "10")
dyskolia.place(x=140, y=130)
# Σχόλιο για buttons
Button(window, text="Προσθήκη",
       command=lambda: add_duties(titlos.get(), dyskolia.get(), categoria.get(), hour.get(), minutes.get(), iduser),
       width=13).place(x=20, y=160)
Button(window, text="Τροποποίηση", command=lambda: up_duties(), width=13).place(x=130, y=160)
Button(window, text="Διαγραφή", command=lambda: del_duty(), width=13).place(x=240, y=160)
Button(window, text="Προβολή", command=show_duties, width=13).place(x=350, y=160)

# Στήλες
cols = ('ID', 'Δραστηριότητα', 'Δυσκολία', 'Κατηγορία', 'Χρόνος')

# Η Treeview Επιτρέπει την παρουσίαση πληροφορίας ιεραρχικής δομής
listBox = ttk.Treeview(window, columns=cols, show='headings')
listBox.column('ID', width=40)
listBox.column('Δραστηριότητα', width=140)
listBox.column('Κατηγορία', width=100)
listBox.column('Δυσκολία', width=70)
listBox.column('Χρόνος', width=100)

# Δημιουργούμε τη Scrollbar
sb = ttk.Scrollbar(window, orient="vertical", command=listBox.yview)

# Τοποθετώ την Scrollbar
sb.place(x=460, y=200, height=226)
listBox.configure(yscrollcommand=sb.set)

for col in cols:
    listBox.heading(col, text=col)
    listBox.grid(row=1, column=0, columnspan=2)
    listBox.place(x=10, y=200)

show_duties()
listBox.bind('<Double-Button-1>', GetValue)

# Θα εμφανίζει ένα status bar
status_bar = Label(window, text="Version 1.0   ", anchor=E)
status_bar.pack(fill=X, side=BOTTOM, ipady=4)

# Εμφάνιση του μενού
window.config(menu=menubar)
window.iconbitmap('freetime.ico')
window.mainloop()
