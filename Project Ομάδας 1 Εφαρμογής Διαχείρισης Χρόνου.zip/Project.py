import tkinter as tk
from tkinter import ttk, messagebox
from tkinter import *
import sqlite3
import matplotlib.pyplot as plt
from pandas import DataFrame

iduser = None

# Σύνδεση με τη βάση μέσω του αντικειμένου mycursor της μεθόδου cursor()
db = sqlite3.connect("Project.db")
mycursor = db.cursor()

# Δημιουργία του παραθύρου του γραφικού περιβάλλοντος
window = Tk()
window.title("Διαχειριστής Ελεύθερου Χρόνου και Υποχρεώσεων")
window.geometry('900x600+500+50')


# Αποθήκευση του ονόματος του νέου χρήστη στη βάση
def create_user(name, nu):
    try:
        # Σύνδεση με τη βάση δεδομένων 
        db = sqlite3.connect("Project.db")
        mycursor = db.cursor()

        # Εισαγωγή νέου χρήστη στον πίνακα users
        sql = "INSERT INTO users (name) VALUES(?)"
        val = (name,)
        mycursor.execute(sql, val)
        db.commit()
        messagebox.showinfo("Ολοκληρώθηκε!", "Ο χρήστης καταχωρήθηκε με επιτυχία!")

        # Επιλογή όλων των χρηστών από τη βάση, συμπεριλαμβανομένου και του νέου χρήστη που μόλις προστέθηκε
        sql1 = "SELECT * FROM users"
        mycursor.execute(sql1)
        users = mycursor.fetchall()
        db.close()

        # Ενημέρωση του combobox user_id με τα στοιχεία του νέου χρήστη 
        user_id['values'] = [f"{user[1]}" for user in users]

        #Κλείσιμο του παραθύρου διαλόγου
        nu.destroy()

    except Exception as e:
        messagebox.showerror("Σφάλμα κατά τη δημιουργία νέου χρήστη", f"Το σφάλμα είναι:{e}")


# Δημιουργία νέου χρήστη
def new_user():
    # Δημιουργία νέου παραθύρου Toplevel
    nu = Toplevel()
    nu.geometry("300x200")
    nu.title("Είσοδος Χρήστη")
    nu.iconbitmap('freetime.ico')

    # Δημιουργία και τοποθέτηση Label για το όνομα χρήστη
    nu_window = Label(nu, text="Όνομα Χρήστη:")
    nu_window.pack(pady=10)

    # Δημιουργία και τοποθέτηση πλαισίου κειμένου για την είσοδο του ονόματος χρήστη
    nu_entry = Entry(nu, width=30)
    nu_entry.pack(pady=10)

    # Δημιουργία και τοποθέτηση κουμπιού για την αποθήκευση του χρήστη
    nu_button = Button(nu, text="Aποθήκευση Χρήστη", command=lambda: create_user(nu_entry.get(), nu))
    nu_button.pack(pady=10)


#Επιλέγω το χρήστη από τον πίνακα users της βάσης
def select_user(name):
    try:
        # Σύνδεση με τη βάση δεδομένων
        db = sqlite3.connect("Project.db")
        mycursor = db.cursor()

        # Επιλογή του ID χρήστη από τον πίνακα users με βάση το όνομα
        sql = "SELECT iduser FROM users WHERE name=?"
        val = (name,)
        mycursor.execute(sql, val)
        id = mycursor.fetchall()
        db.close()

        global iduser
        iduser = id[0][0]  # Ανάθεση του ID χρήστη στη μεταβλητή iduser

        messagebox.showinfo("Ολοκληρώθηκε!", "Ο χρήστης επιλέχθηκε με επιτυχία!")

        # Διαγραφή των περιεχομένων των πλαισίων κειμένου όταν επιλέγεται ένας νέος χρήστης
        SAX.delete(0, END)
        MDX.delete(0, END)
        wres.delete(0, END)

        # Εμφάνιση των δραστηριοτήτων του συγκεκριμένου χρήστη 
        show_duties()

    except Exception as e:
        messagebox.showerror("Σφάλμα κατά την επιλογή χρήστη!", f"Το σφάλμα είναι: {e}")


# Εμφάνιση των υποχρεώσεων του χρήστη στο Treeview table, ταξινομημένων ως προς την σπουδαιότητά τους
def show_duties():
    # Σύνδεση με τη βάση δεδομένων
    db = sqlite3.connect("Project.db")
    mycursor = db.cursor()

    # Ανάκτηση τω δραστηριοτήτων του χρήστη από τη βάση δεδομένων
    sql = "SELECT id, title, importance,category, time FROM duties WHERE iduser=? ORDER BY importance DESC;"
    val = (iduser,)
    mycursor.execute(sql, val)
    records = mycursor.fetchall()
    db.close()

    # Εκκαθάριση του πίνακα (treeview) table1 από προηγούμενες εγγραφές
    for record in table1.get_children():
        table1.delete(record)

    # Εισαγωγή των νέων εγγραφών στον πίνακα (treeview) table1
    if records:
        for record in records:
            table1.insert("", "end", values=record)


#Καταχώρηση νέας δραστηριότητας στη βάση
def add_duties(title, importance, category, time, iduser):
    # Αν έχει επιλεγεί ο χρήστης
    if iduser:
        # Σύνδεση με τη βάση δεδομένων
        db = sqlite3.connect("Project.db")
        mycursor = db.cursor()

        # Εντολή για την εισαγωγή νέας δραστηριότητας
        sql = "INSERT INTO duties(title, importance, category,time, iduser) VALUES(?,?,?,?,?)"
        val = (title, importance, category, time, iduser)

        # Έλεγχος αν τα απαιτούμενα πεδία είναι συμπληρωμένα
        if title == '' or importance == '' or category == '':
            messagebox.showwarning("Προσοχή!", "Παρακαλώ εισάγετε τιμές στα απαιτούμενα πεδία!")
        else:
            #  Εκτέλεση της εντολής και καταχώρηση στη βάση δεδομένων
            mycursor.execute(sql, val)
            db.commit()
            db.close()
            messagebox.showinfo("Προσθήκη δραστηριότητας", "Η δραστηριότητα έχει προστεθεί με επιτυχία!")

            # Διαγράφεται το περιεχόμενο των πλαισίων κειμένου (entry)
            idDuties.delete(0, END)
            titlos.delete(0, END)
            simasia.delete(0, END)
            categoria.delete(0, END)
            hours.delete(0, END)

            # Εμφάνιση των ενημερωμένων δραστηριοτήτων του χρήστη
            show_duties()
    else:
        messagebox.showwarning('Προσοχή!', 'Δεν έχει επιλεγεί χρήστης!')


#Ενημέρωση μιας υπάρχουσας εγγραφής στη βάση
def up_duties():
    # Αν έχει επιλεγεί ο χρήστης
    if iduser:
        # Λήψη δεδομένων από τα πλαίσια εισαγωγής
        id = idDuties.get()
        title = titlos.get()
        category = categoria.get()
        importance = simasia.get()
        time = hours.get()

        # Αν έχει επιλεγεί δραστηριότητα
        if id.isdigit():
            try:
                # Σύνδεση με τη βάση δεδομένων
                db = sqlite3.connect("Project.db")
                mycursor = db.cursor()

                # Εντολή για την ενημέρωση της δραστηριότητας
                sql = "UPDATE duties SET title=?, category=?, importance=?,time=? WHERE id=?"
                val = (title, category, importance, time, id)
                mycursor.execute(sql, val)
                db.commit()
                db.close()

                messagebox.showinfo("Ενημέρωση", "Τα στοιχεία της δραστηριότητας ενημερώθηκαν!")

                # Διαγράφεται το περιεχόμενο των πλαισίων εισαγωγής (entry)
                idDuties.delete(0, END)
                titlos.delete(0, END)
                simasia.delete(0, END)
                categoria.delete(0, END)
                hours.delete(0, END)

                # Εμφάνιση των ενημερωμένων δραστηριοτήτων του χρήστη
                show_duties()
            except Exception as e:
                messagebox.showerror("Σφάλμα κατά την ενημέρωση της δραστηριότητας!", f"Το σφάλμα είναι: {e}")
        else:
            messagebox.showwarning('Προσοχή!', 'Δεν έχετε επιλέξει δραστηριότητα!')
    else:
        messagebox.showwarning('Προσοχή!', 'Δεν έχει επιλεγεί χρήστης!')


#Διαγραφή εγγραφής από τη βάση
def del_duty():
    # Aν έχει επιλεγεί χρήστης
    if iduser:
        try:
            # Σύνδεση στη βάση δεδομένων
            db = sqlite3.connect("Project.db")
            mycursor = db.cursor()
            # Ερώτημα για διαγραφή εγγραφής από τον πίνακα duties βάσει του id
            sql = "DELETE FROM duties WHERE id=?"
            val = (idDuties.get(),)
            mycursor.execute(sql, val)

            # Έλεγχος αν δεν επηρεάστηκε καμία εντολή στη βάση
            if mycursor.rowcount == 0:
                messagebox.showwarning("Προειδοποίηση", "Δεν βρέθηκε εγγραφή με το συγκεκριμένο ID.")
            else:
                # Επιβεβαίωση της διαγραφής και αποθήκευση αλλαγών στη βάση
                db.commit()

                messagebox.showinfo("Ενημέρωση", "Η δραστηριότητα διαγράφηκε επιτυχώς!")

            # Διαγράφεται το περιεχόμενο των πλαισίων κειμένου (entry)
            idDuties.delete(0, END)
            titlos.delete(0, END)
            simasia.delete(0, END)
            categoria.delete(0, END)
            hours.delete(0, END)

            # Εμφάνιση των δραστηριοτήτων 
            show_duties()

            # Κλείσιμο σύνδεσης με τη βάση δεδομένων
            db.close()
        except Exception as e:
            messagebox.showerror('Σφάλμα κατά τη διαγραφή της δραστηριότητας!', f'Το σφάλμα είναι:{e}')
    else:
        messagebox.showwarning('Προσοχή!', 'Δεν έχει επιλεγεί χρήστης!')


# H συνάρτηση καλείται όταν πατήσω διπλό κλικ (event) σε μια γραμμή του Treeview
# Εμφανίζει την πληροφορία για τη δραστηριότητα που επιλέχτηκε από το Treeview στα πλαίσια κειμένου

def GetValue(event):
    try:
        # Καθαρίζουμε τα πεδία κειμένου για να είμαστε έτοιμοι για νέα εισαγωγή δεδομένων
        idDuties.delete(0, END)
        titlos.delete(0, END)
        simasia.delete(0, END)
        categoria.delete(0, END)
        hours.delete(0, END)

        # Ανάκτηση του row_id της επιλεγμένης γραμμής από τον πίνακα table1
        row_id = table1.selection()[0]

        # Ανάκτηση των τιμών από την επιλεγμένη γραμμή σε ένα λεξικό με τη χρήση της μεθόδου set() του table1
        select = table1.set(row_id)

        # Εισαγωγή των τιμών από το λεξικό στα αντίστοιχα πεδία κειμένου
        idDuties.insert(0, select['ID'])
        titlos.insert(0, select['Δραστηριότητα'])
        categoria.insert(0, select['Κατηγορία'])
        hours.insert(0, select['Χρόνος'])
        simasia.insert(0, select['Σημαντικότητα'])

    except Exception as e:
        messagebox.showerror("Κάτι δεν πήγε καλά!", f"Το σφάλμα είναι:{e}")


# Εμφάνιση ενός Treeview που περιέχει τις εφικτές δραστηριότητες της εβδομάδας
def create_sorted_treeview():
    # Έλεγχος σν έχει επιλεγεί χρήστης
    if iduser:
        # Σύνδεση στη βάση δεδομένων 
        db = sqlite3.connect("Project.db")
        mycursor = db.cursor()
        mycursor.execute(
            "SELECT id, title, importance, category, time FROM duties WHERE iduser=? ORDER BY importance DESC",
            (iduser,))
        data = mycursor.fetchall()
        db.close()

        # Φιλτράρισμα δεδομένων ώστε ο χρόνος να είναι o συνολικός διαθέσιμος χρόνος 
        wres_value = wres.get()
        if wres_value.isdigit():
            xronos = int(wres_value)
            filtered_data = []
            total_time = 0
            for entry in data:
                if total_time + int(entry[4]) <= xronos:
                    filtered_data.append(entry)
                    total_time += int(entry[4])
                else:
                    remaining_time = xronos - total_time
                    if remaining_time > 0:
                        filtered_data.append((entry[0], entry[1], entry[2], entry[3], remaining_time))
                        messagebox.showinfo("Περιορισμός Χρόνου",
                                            f"Για τη δραστηριότητα '{entry[1]}' έχεις μόνο {remaining_time} ώρες")
                    break

            #Δημιουργία νέου Treeview
            new_window = Toplevel()
            new_window.title("Εφικτές δραστηριότητες")
            new_window.geometry('400x350')
            new_window.iconbitmap("freetime.ico")

            global table2

            # Το νέο Treeview με τις ίδιες στήλες
            cols = ('ID', 'Δραστηριότητα', 'Σημαντικότητα', 'Κατηγορία', 'Χρόνος')
            table2 = ttk.Treeview(new_window, columns=cols, show='headings')

            #Προσαρμογή στηλών
            table2.column('ID', width=30)
            table2.column('Δραστηριότητα', width=110)
            table2.column('Σημαντικότητα', width=90, anchor=CENTER)
            table2.column('Κατηγορία', width=110)
            table2.column('Χρόνος', width=50, anchor=CENTER)

            #Προσθήκη επικεφαλίδων στηλών
            table2.heading('ID', text='ID')
            table2.heading('Δραστηριότητα', text='Δραστηριότητα')
            table2.heading('Σημαντικότητα', text='Σημαντικότητα')
            table2.heading('Κατηγορία', text='Κατηγορία')
            table2.heading('Χρόνος', text='Χρόνος')

            #Προσθήκη φιλτραρισμένων και ταξινομημένων δεδομένων
            for item in filtered_data:
                table2.insert("", 'end', values=item)

                #Τοποθέτηση του Treeview στο νέο παράθυρο
                table2.pack(fill='both', expand=True)

            #Δημιουργία και προσθήκη κουμπιού για το γράφημα
            button_create_chart = Button(new_window, text="Δημιουργία Γραφήματος", command=create_chart)
            button_create_chart.pack()

        else:
            messagebox.showwarning('Προσοχή!', 'Δεν έχεις καθορίσει το χρόνο!')

    else:
        messagebox.showwarning('Προσοχή!', 'Δεν έχει επιλεγεί χρήστης!')


# Δημιουργία γραφήματος πίτας των ποσοστών χρόνου εφικτών δραστηριοτήτων υποχρεώσεων και ελεύθερου χρόνου
def create_chart():
    #Ανάκτηση δεδομένων από το Treeview με όνομα table2
    data = table2.get_children()
    if data:
        # Εύρεση συνολικού χρόνου για τις εφικτές δραστηριότητες υποχρεώσεων (obligation_time) και του ελεύθερου χρόνου (free_time)
        obligation_time = 0
        free_time = 0

        for i in data:
            values = table2.item(i, 'values')
            category = values[3]
            time = int(values[4])

            if category == 'Υποχρέωση':
                obligation_time += time
            elif category == 'Ελεύθερου Χρόνου':
                free_time += time

        #Δημιουργία γραφήματος πίτας
        labels = ['Υποχρεώσεις', 'Ελεύθερος Χρόνος']
        slices = [obligation_time, free_time]
        colors = ['darkgoldenrod', 'royalblue']
        explode = [0, 0.2]  # Απομακρύνεται μόνο το δεύτερο κομμάτι (Ελεύθερος χρόνος)

        plt.pie(slices, labels=labels, colors=colors, explode=explode,
                autopct='%1.1f%%', shadow=True, startangle=60)
        plt.title('Ποσοστά Χρόνου Δραστηριοτήτων')
        plt.show()
    else:
        messagebox.showinfo('Πληροφορία', 'Δεν υπάρχουν δεδομένα!')

    # Εύρεση συνολικού χρόνου όλων των δραστηριοτήτων που δήλωσε ο χρήστης


def sum_time():
    # Έλεγχος αν έχει επιλεγεί χρήστης
    if iduser:
        # Σύνδεση στη βάση δεδομένων
        db = sqlite3.connect("Project.db")
        mycursor = db.cursor()

        # Δημιουργία ερωτήματος για την εύρεση του συνολικού χρόνου
        sql = "SELECT SUM(time) FROM duties WHERE iduser=?"
        val = (iduser,)
        mycursor.execute(sql, val)

        sum = mycursor.fetchone()[0]

        db.close()
        # Αν το άθροισμα δεν είναι None
        if sum:
            # Καθαρισμός του πεδίου SAX και εισαγωγή του συνολικού χρόνου
            SAX.delete(0, END)
            SAX.insert(0, sum)
        else:
            messagebox.showwarning('Προσοχή!', 'Αυτός ο χρήστης δεν έχει δραστηριότητα!')
    else:
        messagebox.showwarning('Προσοχή!', 'Δεν έχει επιλεγεί χρήστης!')


# Εύρεση μέσου όρου των δραστηριοτήτων ανά ημέρα
def avg_time():
    # Έλεγχος αν έχει επιλεγεί χρήστης
    if iduser:
        # Σύνδεση στη βάση δεδομένων
        db = sqlite3.connect("Project.db")
        mycursor = db.cursor()

        # Δημιουργία ερωτήματος για την εύρεση του συνολικού ελεύθερου χρόνου
        sql = "SELECT SUM(time) FROM duties WHERE iduser=? AND category='Ελεύθερου Χρόνου' "
        val = (iduser,)
        mycursor.execute(sql, val)
        sum = mycursor.fetchone()[0]
        db.close()

        # Αν το άθροισμα δεν είναι None
        if sum:
            # Καθαρισμός του πεδίου MDX και εισαγωγή του μέσου όρου του συνολικού ελεύθερου χρόνου 
            MDX.delete(0, END)
            MDX.insert(0, round(int(sum) / 7, 2))
        else:
            messagebox.showwarning('Προσοχή!', 'Αυτός ο χρήστης δεν έχει δραστηριότητα!')
    else:
        messagebox.showwarning('Προσοχή!', 'Δεν έχει επιλεγεί χρήστης!')


# Άνοιγμα του αρχείου pdf με την περιγραφή του ομαδικού προγραμματιστικού project στα Windows
def openFile():
    # Εισαγωγή της βιβλιοθήκης os για τη διαχείριση αρχείων και φακέλων
    import os
    filename = "08.pdf"
    # Έλεγχος αν το αρχείο υπάρχει
    if os.path.isfile(filename):
        # Άνοιγμα του αρχείου
        os.startfile(filename)
    else:
        messagebox.showerror('Σφάλμα', 'Το αρχείο με την περιγραφή της εφαρμογής δεν βρέθηκε!')


# Αποθήκευση των δραστηριοτήτων του επιλεγμένου χρήστη σε αρχείο με τη βοήθεια DataFrame
def Data_Export():
    # Έλεγχος αν έχει επιλεγεί χρήστης
    if iduser:
        try:
            # Σύνδεση στη βάση δεδομένων
            db = sqlite3.connect("Project.db")
            mycursor = db.cursor()

            # Ανάκτηση του ονόματος του χρήστη
            sql = "SELECT name FROM users WHERE iduser=?"
            val = (iduser,)
            mycursor.execute(sql, val)
            user_name = mycursor.fetchone()[0]

            #Ανάκτηση των δραστηριοτήτων του χρήστη        
            sql = "SELECT title, importance, category, time FROM duties WHERE iduser=? ORDER BY importance DESC;"
            val = (iduser,)
            drast = mycursor.execute(sql, val)

            # Δημιουργία DataFrame από τα αποτελέσματα
            df = DataFrame(drast)
            df.columns = ['Τίτλος', 'Σημαντικότητα', 'Κατηγορία', 'Χρόνος']

            db.close()

            # Eγγραφή των δεδομένων στο αρχείο export.txt
            tfile = open('export.txt', 'w', encoding='utf-8')
            tfile.write(f"Χρήστης: {user_name}\n\n")
            tfile.write(df.to_string(index=False))
            tfile.close()

            messagebox.showinfo('Ενημέρωση', 'Το αρχείο export.txt αποθηκεύτηκε με επιτυχία')

        except Exception as e:
            messagebox.showerror("Σφάλμα κατά την εγγραφή στο αρχείο", f"Το σφάλμα είναι:{e}")
    else:
        messagebox.showwarning('Προσοχή!', 'Δεν έχει επιλεγεί χρήστης!')

    # Δημιουργία του μενού


menubar = tk.Menu(window)

# Προσθέτω στο μενού την επιλογή App για έξοδο από την εφαρμογή
file = Menu(menubar, tearoff=False)
menubar.add_cascade(label='App', menu=file)
file.add_command(label='Exit Application', command=window.destroy)

# Προσθέτω στο μενού την επιλογή Νew User για την εισαγωγή νέου χρήστη
user = Menu(menubar, tearoff=False)
menubar.add_cascade(label='New User', menu=user)
user.add_command(label='Create New User', command=lambda: new_user())

# Προσθέτω στο μενού πληροφορίες για την εφαρμογή 
help = Menu(menubar, tearoff=False)
menubar.add_cascade(label='Help', menu=help)
help.add_command(label='App Information', command=lambda: openFile())

# Εισαγωγή ετικετών για τις υποχρεώσεις
Label(window, text="Χρήστης:").place(x=10, y=10)
Label(window, text="Δραστηριότητα:").place(x=10, y=40)
Label(window, text="Κατηγορία:").place(x=10, y=70)
Label(window, text="Απαιτούμενος Χρόνος σε ώρες:").place(x=10, y=100)
Label(window, text="Βαθμός σημαντικότητας:").place(x=10, y=130)

# Δημιουργία combobox και εμφάνιση των χρηστών της βάσης στο combobox 
user_id = ttk.Combobox(window, width=27)
user_id.place(x=160, y=10)

sql = "SELECT name FROM users"
mycursor.execute(sql)
user_id['values'] = mycursor.fetchall()

# Επιλογή του χρήστη από το combobox
ou_button = tk.Button(text="Επιλογή", command=lambda: select_user(user_id.get()))
ou_button.place(x=360, y=7)

# Πεδίο εισαγωγής κειμένου για τον κωδικό της δραστηριότητας
idDuties = Entry(window, width=3)
idDuties.place(x=110, y=40)

# Πεδίο εισαγωγής κειμένου για τον τίτλο της δραστηριότητας
titlos = Entry(window, width=30)
titlos.place(x=160, y=40)

#Δημιουργία combobox για τις κατηγορίες δραστηριοτήτων
categoria = ttk.Combobox(window, width=27)
categoria['values'] = ("Υποχρέωση", "Ελεύθερου Χρόνου")
categoria.place(x=160, y=70)

#Δημιουργία spinbox για εισαγωγή χρόνου
hours = Spinbox(window, from_=0, to=100, text=" ", width=5)
hours.place(x=195, y=100)

#Δημιουργία combobox για εισαγωγή σημαντικότητας της δραστηριότητας
simasia = ttk.Combobox(window, width=8)
simasia['values'] = ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10')
simasia.place(x=160, y=130)

#Εισαγωγή των buttons για επεξεργασία δραστηριοτήτων
Button(window, text='Προσθήκη',
       command=lambda: add_duties(titlos.get(), simasia.get(), categoria.get(), hours.get(), iduser), width=13).place(
    x=20, y=160)
Button(window, text='Τροποποίηση', command=lambda: up_duties(), width=13).place(x=130, y=160)
Button(window, text='Διαγραφή', command=lambda: del_duty(), width=13).place(x=240, y=160)

# Στήλες του πίνακα δραστηριοτήτων
cols = ('ID', 'Δραστηριότητα', 'Σημαντικότητα', 'Κατηγορία', 'Χρόνος')

# Δημιουργία Treeview για την εμφάνιση των δραστηριοτήτων του χρήστη
table1 = ttk.Treeview(window, columns=cols, show='headings')

table1.column('ID', width=30)
table1.column('Δραστηριότητα', width=110)
table1.column('Σημαντικότητα', width=90, anchor=CENTER)
table1.column('Κατηγορία', width=110)
table1.column('Χρόνος', width=50, anchor=CENTER)

table1.heading('ID', text='ID')
table1.heading('Δραστηριότητα', text='Δραστηριότητα')
table1.heading('Σημαντικότητα', text='Σημαντικότητα')
table1.heading('Κατηγορία', text='Κατηγορία')
table1.heading('Χρόνος', text='Χρόνος')

table1.place(x=10, y=200, height=226)

# Δημιουργία της Scrollbar για το table1
sb = ttk.Scrollbar(window, orient='vertical', command=table1.yview)
table1.configure(yscrollcommand=sb.set)
sb.place(x=400, y=200, height=226)

# Επιλογή δραστηριότητας του table1 με διπλό κλικ και κλήση της συνάρτησης GetValue για την επιλογή
table1.bind('<Double-Button-1>', GetValue)

# Κλήση της συνάρτησης create_sorted_treeview για την εμφάνιση των εφικτών δραστηριοτήτων της εβδομάδας
efiktes = Button(window, text="Εφικτές δραστηριότητες εβδομάδας", command=create_sorted_treeview)
efiktes.place(x=10, y=450)

# Ετικέτες και κουμπιά για την εμφάνιση του συνολικού χρόνου των δραστηριοτήτων
Label(window, text="Συνολικός Χρόνος Δραστηριοτήτων:").place(x=500, y=60)
SAX = Entry(window, width=6)
SAX.place(x=750, y=60)
Button(window, text="Εμφάνιση", command=lambda: sum_time()).place(x=800, y=57)

# Ετικέτες και κουμπιά για την εμφάνιση του μέσου χρόνο δραστηριοτήτων ανά ημέρα
Label(window, text="Μέσος χρόνος δραστηριοτήτων ελεύθερου χρόνου ανά ημέρα:", wraplength=200, justify='left').place(
    x=500, y=90)
MDX = Entry(window, width=6)
MDX.place(x=750, y=95)
Button(window, text="Εμφάνιση", command=lambda: avg_time()).place(x=800, y=92)

# Κουμπί για την κλήση της συνάρτησης που αποθηκεύει σε αρχείο κειμένου τις δραστηριότητες του συγκεκριμένου χρήστη
Button(window, text='Εξαγωγή των δραστηριοτήτων σε αρχείο', command=lambda: Data_Export()).place(x=500, y=160)

# Βασική πληροφορία σε ετικέτα
longtext = "Δώσε πρώτα το συνολικό διαθέσιμο χρόνο για να δεις ποιες είναι οι εφικτές δραστηριότητες."
labelframe = tk.LabelFrame(window, text="Προσοχή!", fg='#cd178c')
labelframe.place(x=500, y=220, width=300, height=90)

label = tk.Label(labelframe, text=longtext, wraplength=290, justify='center', fg='#000080')
label.place(relx=0.5, rely=0.5, anchor='center')

Label(window, text="  Πληροφορία: Η εβδομάδα έχει 168 ώρες!", fg='#cd178c').place(x=500, y=320)

# Ετικέτα και πεδίο εισαγωγής για το διαθέσιμο χρόνο την εβδομάδα σε ώρες
Label(window, text="Διαθέσιμος χρόνος την εβδομάδα σε ώρες:").place(x=500, y=400)
wres = Entry(window, width=6)
wres.place(x=750, y=400)

#Εμφάνιση Μενού
window.config(menu=menubar)

# Ορισμός του εικονιδίου παραθύρου
window.iconbitmap("freetime.ico")

# Κλείσιμο της σύνδεσης με τη βάση δεδομένων
db.close()

#Διατήρηση του παραθύρου ώστε να ανταποκρίνεται στις ενέργειες του χρήστη
window.mainloop()
